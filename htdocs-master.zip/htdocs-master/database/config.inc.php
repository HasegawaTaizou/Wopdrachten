<?php
$db['server'] = 'localhost';
$db['user'] = 'root';
$db['password'] = '';
$db['database'] = 'appotheekdb';
$beheerder_ids = array(1);
?>
