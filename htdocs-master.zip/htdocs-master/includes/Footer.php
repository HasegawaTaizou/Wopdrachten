<div class="footer">
	&copy; <?php print date("Y");?>
  Wil je contact?<a href="service.php">Mail</a> naar: <strong>J.Schut@huisarts.net</strong>.</br>
  Wil je een fout opgeven?<a href="service.php">Mail</a> naar:<strong>Nickklaver11@gmail.com</strong>.
</div>
