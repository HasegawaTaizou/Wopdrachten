<?php include("includes/configtitle.php") ?>
<!DOCTYPE html>
<html>
		<head>

			<!--Meta informatie hieronder-->
<?php include("includes/HEAD.php")
?>
		</head>
	<body>

		<!--Dit is het logo en de banner aan de bovenkant van de pagina-->


		<!--Dit is de navigatie-->
		<?php include("includes/navbar.php") ?>

		<!--Hierin komt de content-->
		<div class="content">
		<center><h1><b> Afspraak maken?</b></h1>
		<p> U kunt telefonisch of in de praktijk een afspraak maken.</p>
		<hr>
		<h1><b>Vragen over de medicatie?</b></h1>
		<p>Als u vragen hebt over de medicatie, dan kunt u naar de balie lopen<br>
		en u vraag stellen. Als u dan nog niet genoeg weet kunt u dan heb kunt<br> u nog een kijkje nemen op onze website.</p>
		<hr>
		<img src="Images/Apotheekbalie.jpg">
		<hr>
		<h1> Onze openingstijden</h1>
		<p>Wij zijn van 8:00 t/m 17:00 geopend, en dat van maandag t/m zaterdag.<br>
		Zondag zijn wij ook geopend, maar dan van 10:00 tot 16:00.</p>
		<hr>
		<h1> Wilt u een herhalingsrecept?</h1>
		<p> U kunt dat aanvragen om een formulier in te vullen(U kunt er alleen in aanmerking<br> komen als u een chronische ziekte heeft, de dokter of het advies van het ziekenhuis.) </p>
		<br><hr>
		</center>

		</div>



		<!--Dit is de Footer-->
	<?php include("includes/Footer.php") ?>
	</body>
</html>
