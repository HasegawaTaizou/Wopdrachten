<?php
require 'fpdf.php';

class PDF extends FPDF
{

  function Header()
  {
    $front_family='Arial';
    $bold = 'B';
    $front_size = 16;

    $this->SetFont($front_family,$bold,$front_size);

    $width=40;
    $height=10;
    $text="bestelling";

    $this->Cell($width,$height,$text);
    $this->Ln();
  }
}
$pdf = new PDF();
$pdf->AddPage();
$front_family='Arial';
$bold = '';
$front_size = 12;
$pdf->SetFont($front_family,$bold,$front_size);
$pdf->Cell(40,10,'test');
$pdf->Output();
?>
