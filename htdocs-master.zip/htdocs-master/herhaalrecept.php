<?php include("includes/configtitle.php") ?>
<!DOCTYPE html>
	<html>
		<head>

			<!--Meta informatie hieronder-->
			<?php include("includes/HEAD.php")
			?>
		</head>
	<body>
		<!--Dit is de navigatie-->
		<?php include("includes/navbar.php") ?>


    <?php include("includes/Footer.php") ?>
    </body>
    </html>
