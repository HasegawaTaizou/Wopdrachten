<?php
include('database/logincheck_beheer.inc.php');

if (!empty($_POST['username']) && !empty($_POST['password'])) {
    $wachtwoord = hash('sha256', $_POST['password']);
    $sql = "SELECT
    `id`
    FROM `gebruikers`
    WHERE `gebruikersnaam` = '" . mysqli_real_escape_string($link, $_POST['username']) . "'
    AND `wachtwoord` = '" . mysqli_real_escape_string($link, $wachtwoord) . "'
    LIMIT 1";
    $result = mysqli_query($link, $sql);
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_row($result);
        $cookie['id'] = $row[0];
        $cookie['password'] = $wachtwoord;
        setcookie('login', serialize($cookie), time() + 60*60*24*7*2, '/');
        $login_correct = TRUE;
    }
    else {
        $login_error = TRUE;
    }
}
?>
<?php include("includes/configtitle.php") ?>
<!DOCTYPE HTML>
<html>
<head>
  <?php include("includes/HEAD.php")
  ?>
</head>
<?php include("includes/navbar.php") ?>
<body>
<div class="container">
<h1>Overzicht gebruikers</h1>
<div class="link">
  <p><a href="AdminAddLogin.php">Nieuwe gebruiker</a></p>
</div>
<div class="overzicht">
  <?php
  $link = mysqli_connect($db['server'], $db['user'], $db['password'], $db['database']);
  $sql = "SELECT * FROM `gebruikers`";
  $result = mysqli_query($link, $sql);
  if (mysqli_num_rows($result) > 0) {
      echo '<table id="customers">';
      echo '<tr><th>Gebruikersnaam</th><th>E-mailadres</th><th>laatst_ingelogd</th><th>verwijder:</th></tr>';
      while ($data = mysqli_fetch_assoc($result)) {
          echo '<tr>';
          echo '<td>' . htmlspecialchars($data['gebruikersnaam']) . '</td>';
          echo '<td>' . htmlspecialchars($data['email']) . '</td>';
          echo '<td>' . htmlspecialchars($data['laatst_ingelogd']) . '</td>';
          if (($data['id'])>1) {
            echo '<td><a href="verwijder.php?id=' . $data['id'] . '">Verwijder</a></td>';
          } else {
            echo '<td></td>';
          }
          echo '';
          echo '</tr>';
      }
      echo '</table>';
  }
  else {
      echo '<p>Er zijn geen gebruikers.</p>';
  }
  ?>
<br>
  </div>

  <h1>Upload productinfo and image.</h1>
  <div class="upload image">

    <form action="upload.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <label for="name"><p>naam product:</label>
    <input type="text" id="name" name="name" placeholder="Enter your name here...">
    <label for="discription"><p>Vul hier de description in:</label>
    <textarea id="discription" name="discription" placeholder="write description here" style="height:200px"></textarea>
    <input type="submit" value="upload product" name="submit">
</form>

<h1>Overzicht producten.</h1>
<div class="overzicht">

  <?php
  $id = $_GET['id'];
  $id1 =$id+1 ;
  $id2 =$id-1 ;
  $offset = 10*$id;
  $link = mysqli_connect($db['server'], $db['user'], $db['password'], $db['database']);
  $sql = "SELECT * FROM products LIMIT 10 OFFSET $offset";
  $result = mysqli_query($link, $sql);
  if (mysqli_num_rows($result) > 0) {
      echo '<table id="customers">';
      echo '<tr><th>naam</th><th>description</th><th>id</th><th>image</th><th></th><th></th></tr>';
      while ($data = mysqli_fetch_assoc($result)) {
          echo '<tr>';
          echo '<td>' . htmlspecialchars($data['naam']) . '</td>';
          echo '<td>' . htmlspecialchars($data['description']) . '</td>';
          echo '<td>' . htmlspecialchars($data['id']) . '</td>';
          echo '<td><img style="width=250px;height:250px;" src="' . htmlspecialchars($data['image']) . '"> </td>';
          echo '<td><a href="product.php?id=' . $data['id'] . '">product</a></td>';
          echo '<td><a href="verwijder_product.php?id=' . $data['id'] . '">Verwijder</a></td>';
          echo '';
          echo '</tr>';
      }
      echo '</table>';
      if ($id == 0) {
     echo '<table>';
     echo '<tr><th></th><th></th><th></th></tr>';
     echo '<tr>';
     echo '<td><a href="overzicht.php?id=1">next</a></td>';
     echo '<td><p>'.$id1.'</p></td>';
     echo '</tr>';
     echo '</table>';
     } else {
     echo '<table>';
     echo '<tr><th></th><th></th><th></th><th></th></tr>';
     echo '<tr>';
     echo '<td><a href="overzicht.php?id='.$id2.'">prev</a></td>';
     echo '<td><p>'.$id1.'</p></td>';
     echo '<td><a href="overzicht.php?id='.$id1.'">next</a></td>';
     echo '</tr>';
     echo '</table>';
     }
  }
  else {
      echo '<p>Er zijn geen producten.</p>';
      echo '<a href="overzicht.php?id='.$id2.'">prev</a>';
  }
  ?>
  </div>
</div>
  </div>
<?php include("includes/Footer.php") ?>
</body>
</html>
