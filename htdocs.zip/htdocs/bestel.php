<?php include("includes/configtitle.php") ?>
<?php include("database/config.inc.php") ?>
<!DOCTYPE html>
	<html>
		<head>

			<!--Meta informatie hieronder-->
			<?php include("includes/HEAD.php")
			?>
		</head>
	<body>
		<!--Dit is de navigatie-->
		<?php include("includes/navbar.php") ?>
<div class="overzicht">
    <?php
		$id = $_GET['id'];
		$id1 =$id+1 ;
		$id2 =$id-1 ;
		$offset = 10*$id;
    $link = mysqli_connect($db['server'], $db['user'], $db['password'], $db['database']);
    $sql = "SELECT * FROM products LIMIT 10 OFFSET $offset";
    $result = mysqli_query($link, $sql);
    if (mysqli_num_rows($result) > 0) {
        echo '<table id="customers">';
        echo '<tr><th>naam</th><th>description</th><th></th><th>product</th><th></th></tr>';
        while ($data = mysqli_fetch_assoc($result)) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($data['naam']) . '</td>';
            echo '<td>' . htmlspecialchars($data['description']) . '</td>';
            echo '<td><img style="width=300px;height:300px;" src="' . htmlspecialchars($data['image']) . '"> </td>';
            echo '';
						echo '<td><a href="product.php?id=' . $data['id'] . '">product</a></td>';
            echo '<td><a href="order.php?id=' . $data['id'] . '">bestel</a></td>';
						echo '</tr>';
        }
        echo '</table>';

    }

    else {
        echo '<p>Er zijn geen producten.</p>';
				echo '<a href="bestel.php?id=0">terug naar 0</a>';
    }
		 if ($id == 0) {
		echo '<table>';
		echo '<tr><th></th><th></th><th></th><th></th></tr>';
		echo '<tr>';
		echo '<td><a href="bestel.php?id=1">next</a></td>';
		echo '<td><p>'.$id1.'</p></td>';
		echo '</tr>';
		echo '</table>';
		} else {
    echo '<table>';
		echo '<tr><th></th><th></th><th></th><th></th></tr>';
		echo '<tr>';
		echo '<td><a href="bestel.php?id='.$id2.'">prev</a></td>';
		echo '<td><p>'.$id1.'</p></td>';
		echo '<td><a href="bestel.php?id='.$id1.'">next</a></td>';
    echo '</tr>';
		echo '</table>';
		}
    ?>
		</div>

	    <?php include("includes/Footer.php") ?>
    </body>
    </html>
