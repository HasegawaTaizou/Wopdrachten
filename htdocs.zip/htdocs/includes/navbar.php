<div class="toppage">
  <img src="Images/banner.png" alt="Banner" usemap="#banner">
  <map name="banner">
  <area shape="circle" coords="150,120,120" href="Home.php">
  <area shape="rect" coords="1000,20,1500,60" href="herhaalrecept.php">
  <area shape="rect" coords="1025,80,1450,120" href="nieuw.php">
  <area shape="rect" coords="1100,130,1550,170" href="bestel.php"
  </map>
</div>
    <div class="Navigatie">
    	<ul class="nav nav-pills">
    	  <li class="nav-item">
    	    <a class="nav-link <?php if ($CURRENT_PAGE == "Home") {?>active<?php }?>" href="Home.php">Home</a>
    	  </li>
    	  <li class="nav-item">
    	    <a class="nav-link <?php if ($CURRENT_PAGE == "Info") {?>active<?php }?>" href="info.php">info</a>
    	  </li>
    	  <li class="nav-item">
    	    <a class="nav-link <?php if ($CURRENT_PAGE == "Service") {?>active<?php }?>" href="Service.php">Service</a>
    	  </li>
        <li class="nav-item">
         <a class="nav-link <?php if ($CURRENT_PAGE == "overzicht") {?>active<?php }?>" href="overzicht.php?id=0">beheer(admin)</a>
       </li>
       <li class="nav-item">
        <a class="nav-link <?php if ($CURRENT_PAGE == "herhaalrecept") {?>active<?php }?>" href="herhaalrecept.php">herhaalrecept</a>
      </li>
       <li class="nav-item">
        <a class="nav-link <?php if ($CURRENT_PAGE == "register") {?>active<?php }?>" href="nieuw.php">register</a>
      </li>
      <li class="nav-item">
       <a class="nav-link <?php if ($CURRENT_PAGE == "bestel") {?>active<?php }?>" href="bestel.php?id=0">bestel</a>
     </li>
        <li class="nav-item">
    	    <a class="nav-link <?php if ($CURRENT_PAGE == "Login") {?>active<?php }?>" href="Login.php">login</a>
    	  </li>
    	</ul>
    </div>
