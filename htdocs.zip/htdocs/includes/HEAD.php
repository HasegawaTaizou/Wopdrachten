<title><?php print $PAGE_TITLE;?></title>

<?php if ($CURRENT_PAGE == "Home") { ?>
  <meta name="description" content="HTML,CSS,XML,JavaScript, Apotheek, J.Schut, Dhr.J.Schut, Apotheekhoudend Huisarts">
	<meta name="keywords" content="HTML,CSS,XML,JavaScript, Apotheek, J.Schut, Dhr.J.Schut, Apotheekhoudend Huisarts" />
<?php } ?>
<link rel="icon" href="Images/Logo.png" sizes="300x300">
<meta charset="UTF-8">
<html lang="nl-en">
<meta name="author" content="Wesley van der Slikke, Nick Klaver, Dane Schuijt">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css?family=Russo+One" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Staatliches" rel="stylesheet">
<link  href="http://fonts.googleapis.com/css?family=Reenie+Beanie:regular" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="stylesheet.css">
<link rel="stylesheet" href="tablestyle.css">
